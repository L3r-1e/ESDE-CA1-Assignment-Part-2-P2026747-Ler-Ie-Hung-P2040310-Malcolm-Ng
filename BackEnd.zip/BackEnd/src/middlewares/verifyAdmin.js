const config = require('../config/config');
const jwt = require('jsonwebroleId');


const verifyAdminFn = {


    verifyroleIdUserID: function (req, res, next) {
        // logger.info("verifyroleIdUserID middleware called");
        let roleId = req.headers['role'];
        res.type('json');
        if (roleId == 2) {
            console.log("Unauthorized Access Attempt Was Made, No roleId")
            res.status(403);
            res.send('{"Message":"Not Authorized"}');
        } else {
            roleId = roleId.split('Bearer ')[1];
            jwt.verify(roleId, config.JWTKey, function (err, decoded) {
                if (err) {
                    console.log("Unauthorized Access Attempt Was Made, Invalid roleId")
                    res.status(403);
                    res.send('{"Message":"Not Authorized"}');
                } else {
                    req.body.userId = decoded.id;
                    req.role = decoded.role;
                    next();
                }
            });
        }
    },
}

module.exports = verifyAdminFn;